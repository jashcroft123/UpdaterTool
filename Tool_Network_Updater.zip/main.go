package main

import (
	"fmt"
	"io"
	"os"
	"os/exec"

	"github.com/spf13/viper"
)

//Config file
//local = Path to folder containing "latest" folder, used as a temporary store. The .zip used will be placed into the latest folder along with the executable running
//remote = Path to remote folder containing the versioned zip files
//runexe = the name of the executable to run, multiple could exist within the archive

//Run, - "go run ."
//Build - "go build -o Tool_Network_Updater.exe ."

func main() {

	viper.AddConfigPath(".")
	viper.SetConfigName("config")
	viper.SetConfigType("toml")
	err := viper.ReadInConfig()
	check(err)

	local := viper.GetString("local")
	remote := viper.GetString("remote")
	runexe := viper.GetString("runexe")

	//Program path (latest downloaded, from single folder)
	pathexe := local + "\\latest\\" + runexe

	file, currVersRemote, forced, err := readLatestFromFolder(remote, true, "Remote")

	if err != nil {
		fmt.Println(err)
		launchApp(pathexe)
		os.Exit(0)
	}

	_, currVersLocal, _, err := readLatestFromFolder(local, false, "Local")

	if currVersRemote > currVersLocal || forced {
		fmt.Println("Local:", currVersLocal)
		fmt.Println("Remote", currVersRemote)

		fmt.Println("New version found, updating...")
		//Copy to local path
		dst, err := os.Create(local + "\\" + file)
		check(err)
		src, err := os.Open(remote + "\\" + file)
		check(err)
		_, err = io.Copy(dst, src)
		check(err)

		//Clear latest folder
		err = os.RemoveAll(local + "\\latest")
		check(err)

		src.Close()
		dst.Close()

		//Unzip to local location
		updateLatest(local+"\\"+file, local+"\\latest")

		//Copy zip into latest, root will be deleted
		move, _ := os.Create(local + "\\latest\\" + file)
		src, _ = os.Open(local + "\\" + file)
		_, err = io.Copy(move, src)
		check(err)

		move.Close()
		src.Close()

		//Delete latest local zip copy
		//This allows forced to remain on the network as a single instance
		err = os.RemoveAll(local + "\\" + file)
		check(err)

	}

	//If "Latest" does not exist, i.e. deleted to force next run to use
	//latest from current latest local build (revert builds)
	if _, err = os.Stat(pathexe); os.IsNotExist(err) {
		//Unzip to local location
		updateLatest(local+"\\"+file, local+"\\latest")
	}

	//Finally, lunach the application in "latest" folder which should exist
	launchApp(pathexe)

}

func launchApp(path string) {
	fmt.Println(path)
	cmnd := exec.Command(path)
	err := cmnd.Start()
	check(err)
}
